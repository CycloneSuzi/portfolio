package arraysearch;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Suzanne Townsend. Date: 2017/06/12. Purpose: JAVA PRAC.
 */
public class ArraySearch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean cont = false;
        ArrayList nums = new ArrayList();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.add(4);
        nums.add(5);
        nums.add(6);
        nums.add(7);
        nums.add(8);
        nums.add(9);
        nums.add(10);

        System.out.println("What number would you like to search for?");

        while (!sc.hasNextInt()) {
            System.out.println("please enter a whole number");
            sc.nextLine();
        }
        int input = sc.nextInt();

        for (Object num : nums) {
            if (num.equals(input)) {
                cont = true;
                break;
            }
        }
        if (cont) {
            System.out.println(input + " found in Array");
        } else {
            System.out.println(input + " not found in Array");
        }
    }
}
