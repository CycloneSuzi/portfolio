package createloans;

import createloans.CreateLoans;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

/**
 * @author Suzanne Townsend. Date:2.10/06/12. Purpose: JAVA prac
 */
public class ReadSave extends CreateLoans {

    public void SaveFile() {
        Vector<java.lang.Object> resultVector = new Vector<>();
        resultVector.add(loanArr);
        System.out.println("Saving file....");

        try {
            FileOutputStream fileOut = new FileOutputStream("loan.bin");
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);

            objOut.writeObject(resultVector);
            fileOut.close();
            System.out.println("Save Successful");
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public void ReadFile() {
        //readFile
        System.out.println("Reading from file....");
        Vector v = new Vector();

        try {
            FileInputStream fileLn = new FileInputStream("loan.bin");
            ObjectInputStream objectln = new ObjectInputStream(fileLn);

            v = (Vector) objectln.readObject();
            fileLn.close();
        } catch (IOException err) {
            System.out.println(err);
        } catch (ClassNotFoundException err) {
            System.out.println(err);
        }
        for (int y = 0; y < v.size(); y++) {
            java.lang.Object temp = (java.lang.Object) v.elementAt(y);
        }
    }
}
