package createloans;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.Serializable;
import java.util.Vector;

/**
 * @author Suzanne Townsend. Date:2.10/06/12. Purpose: JAVA prac
 */
public class CreateLoans extends Loan implements Serializable {

    static ArrayList loanArr = new ArrayList();
    static ReadSave rS = new ReadSave();
    static double finalAmount = 0;
    static double intrRate;
    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        RunLoans();
        DisplayLoans();
        rS.SaveFile();
        rS.ReadFile();

    }

    public static void RunLoans() {
        //runLoans
        for (int i = 0; i <= 4; i++) {
            System.out.println("What is the current Prime Interest rate?");
            while (!sc.hasNextDouble()) {
                sc.next();
            }
            intrRate = sc.nextDouble();

            System.out.println("which loan type would you like, Long Term {5}, Mid Term {3}, Short Term {1}");
            while (!sc.hasNextInt()) {
                sc.next();
            }
            int loanType = sc.nextInt();
            switch (loanType) {
                case 1:
                    loanType = shortTerm;
                    break;
                case 3:
                    loanType = midTerm;
                    break;
                case 5:
                    loanType = longTerm;
                    break;
                default:
                    loanType = defaultRate;
                    break;
            }
            System.out.println("Which type of loan are you looking for today, Business {1} or Personal {2}");
            int bOrP = sc.nextInt();
            PersonalLoan pL = new PersonalLoan();
            BusinessLoan bL = new BusinessLoan();

            switch (bOrP) {
                case 1:
                    intrRate = bL.BusinessLoan(intrRate);
                    break;
                case 2:
                    intrRate = pL.PersonalLoan(intrRate);
                    break;

            }
            System.out.println("How much would you like to loan today? $2000 - $250,000?");
            while (!sc.hasNextDouble()) {
                sc.next();
            }
            double amount = sc.nextDouble();
            if (amount >= 100000) {
                System.out.println("Sorry, due to information you have provided we are unable to process your claim");
            } else {
                finalAmount = amount + (amount * intrRate);
            }
            //loans in arrayList
            loanArr.add(intrRate);
            loanArr.add(loanType);
            loanArr.add(bOrP);
            loanArr.add(amount);
            loanArr.add(finalAmount);

        }
    }

    public static void DisplayLoans() {
        for (Object loan : loanArr) {
            System.out.println(loan);
        }
    }
}
