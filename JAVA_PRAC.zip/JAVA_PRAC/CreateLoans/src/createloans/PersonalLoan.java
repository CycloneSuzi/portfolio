package createloans;

/**
 * @author Suzanne Townsend. Date:2.10/06/12. Purpose: JAVA prac
 */
public class PersonalLoan extends Loan {

    double
            PersonalLoan(double v) {
        primeRate = 0.02;
        return primeRate;
    }
}
