package createloans;

/**
 * @author Suzanne Townsend. Date:2.10/06/12. Purpose: JAVA prac
 */
public interface LoanConstants {

    int shortTerm = 1;
    int midTerm = 3;
    int longTerm = 5;
    String companyName = "ABC LOAN CO";
    int maximumLoan = 250000;

}
