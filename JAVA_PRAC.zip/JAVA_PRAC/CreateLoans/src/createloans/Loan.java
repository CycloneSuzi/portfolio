package createloans;

/**
 * @author Suzanne Townsend. Date:2.10/06/12. Purpose: JAVA prac
 */
public abstract class Loan implements LoanConstants {

    private int loanNumber;
    private String custLastName;
    private int loanAmount;
    public static double primeRate;
    public static double primeRateB;
    public static int defaultRate;

    Loan() {

        defaultRate = shortTerm;
    }

    public int getLoanNumber() {
        return loanNumber;
    }

    public String getCustLastName() {
        return custLastName;
    }

    public int getLoanAmount() {
        return loanAmount;
    }

    public void setLoanNumber(int loanNumber) {
        this.loanNumber = loanNumber;
    }

    public void setCustLastName(String custLastName) {
        this.custLastName = custLastName;
    }

    public void setLoanAmount(int loanAmount) {
        this.loanAmount = loanAmount;
    }

    public void displayData() {
        System.out.println("Loan number: " + getLoanNumber() + "\n Last Name: "
                + getCustLastName() + "\n Loan amount: "
                + getLoanAmount() + "\n Interest Rate: " + primeRate);
    }

}
