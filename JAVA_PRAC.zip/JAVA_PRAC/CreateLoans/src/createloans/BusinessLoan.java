
package createloans;

/**
 * @author Suzanne Townsend. Date:2.10/06/12. Purpose: JAVA prac
 */
public class BusinessLoan extends Loan{

    double
    BusinessLoan(double b){
        
        primeRateB = 0.01;
        
    return primeRateB;
    }    
}
