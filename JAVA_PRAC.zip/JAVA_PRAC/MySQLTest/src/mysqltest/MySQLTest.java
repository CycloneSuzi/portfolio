package mysqltest;

import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author Suzanne Townsend. Date: 2017/06/12. Purpose: JAVA PRAC.
 */
public class MySQLTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PersonDB db = new PersonDB();
        db.setVisible(true);
    }
}
