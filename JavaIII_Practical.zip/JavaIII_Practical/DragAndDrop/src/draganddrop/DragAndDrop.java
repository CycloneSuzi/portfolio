package draganddrop;

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.*;

/**
 *
 * @author Suzanne Townsend. Purpose: Java III Practical Date: 2017-10-05
 */
public class DragAndDrop extends JFrame {

    JTextField field;
    JTextField field1;
    JButton button;
    JButton helpButton;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DragAndDrop DnD = new DragAndDrop();
    }

    public DragAndDrop() {
        setTitle("Java Drag And Drop Demonstration");

        setLayout(null);

        //Set button
        button = new JButton("Change my text");
        helpButton = new JButton("Help Files");

        button.setBounds(30, 10, 150, 25);
        helpButton.setBounds(240, 110, 90, 50);

        //set text field
        field = new JTextField();
        field.setBounds(30, 60, 150, 25);

        //add button and text field to jFrame
        add(button);
        add(helpButton);
        add(field);

        field.setDragEnabled(true);

        button.setTransferHandler(new TransferHandler("text"));

        helpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String url = "help_file.html";

                File htmlFile = new File(url);

                try {
                    Desktop.getDesktop().browse(htmlFile.toURI());
                } catch (IOException ex) {
                    System.out.println("IOException has occured" + ex);
                }
            }
        });

        setSize(350, 200);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

    }

}
