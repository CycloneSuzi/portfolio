
package TestState;

/**
 *
 * @author Suzanne Townsend. Purpose: Java III Practical Date: 2017-10-05
 *
 */
public class State {

    public String getName() {
        return name;
    }

    public int getPopu() {
        return popu;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPopu(int popu) {
        this.popu = popu;
    }
    
    private String name;
    private int popu;
    CapitalCity cC = new CapitalCity();
    
    public State () {
    String capCity;
    double capSize, capPop;
    this.name = "Western Australia";
    this.popu = 2613700;
    capCity = cC.getPerth();
    capPop = cC.getPerthPop();
    capSize = cC.getLandSize();
    System.out.println("State name: " + name
                + "\nState Population: " + popu 
                + "\nCapital City: " + capCity 
                + "\nCapital City Population: " + capPop 
                + "\nCapital City Size: " + capSize +"km²");
    }
    State (String name, int popu, String capCity, int capPop, int capSize) {
        
        name = "Victoria";
        popu = 25000000 * 2;
        capCity = "Melbourne";
        capPop = 15000000 * 2;
        capSize = 9990;
        
        System.out.println("\n\nState name: " + name
                + "\nState Population: " + popu 
                + "\nCapital City: " + capCity 
                + "\nCapital City Population: " + capPop 
                + "\nCapital City Size: " + capSize +"km²");
    }

    private class CapitalCity {

        public String getPerth() {
            return perth;
        }

        public int getPerthPop() {
            return perthPop;
        }

        public double getLandSize() {
            return landSize;
        }

        public void setPerth(String perth) {
            this.perth = perth;
        }

        public void setPerthPop(int perthPop) {
            this.perthPop = perthPop;
        }

        public void setLandSize(double landSize) {
            this.landSize = landSize;
        }
        
        private String perth = "Perth";
        private int perthPop = 1958912;
        private double landSize = 6417.9;
    }
    
}
