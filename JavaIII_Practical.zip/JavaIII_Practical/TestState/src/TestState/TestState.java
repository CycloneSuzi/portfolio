
package TestState;

/**
 *
 * @author Suzanne Townsend. Purpose: Java III Practical Date: 2017-10-05
 *
 */
public class TestState {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        State s = new State();
        State s1 = new State("Victoria", 25000000, "Melbourne", 15000000, 9990);

    }

}
