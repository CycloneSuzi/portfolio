package graphics2d;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JFrame;


/**
 *
 * @author Suzanne Townsend. Purpose: Java III Practical Date: 2017-10-05
 */
public class Graphics2D extends JFrame{

    Font font = new Font("Arial", Font.BOLD,24);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     new Graphics2D();
    }
        
    public Graphics2D() {

        super("Class Paint");
        
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
       
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.BLUE);
        g.setFont(font);
        g.drawString("Java 2D Graphics", 100, 80);
        g.drawRoundRect(120, 100, 160, 160, 25, 25);
        
    }
}
