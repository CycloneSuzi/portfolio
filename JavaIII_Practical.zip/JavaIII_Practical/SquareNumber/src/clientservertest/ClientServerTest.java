/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientservertest;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Suzanne Townsend. Purpose: Java III Practical Date: 2017-10-05
 *
 */
public class ClientServerTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        int num, temp;
        
        Scanner sc = new Scanner(System.in);
        Socket s = new Socket("127.0.0.1", 1742);
        Scanner sc1 = new Scanner(s.getInputStream());
        System.out.println("Enter a number.");
        num = sc.nextInt();
        PrintStream p = new PrintStream(s.getOutputStream());
        p.println(num);
        temp = sc1.nextInt();
        System.out.println(temp);
        
    }

}
