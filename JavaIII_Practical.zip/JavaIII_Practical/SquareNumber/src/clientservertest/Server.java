package clientservertest;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Suzanne Townsend. Purpose: Java III Practical Date: 2017-10-05
 *
 */
public class Server {

    public static void main(String[] args) throws IOException {
        int num, temp;

        ServerSocket s1 = new ServerSocket(1742);
        Socket skt = s1.accept();
        Scanner sc = new Scanner(skt.getInputStream());
        num = sc.nextInt();
        temp = num * num;
        PrintStream p = new PrintStream(skt.getOutputStream());
        p.println(temp);
    }
}
