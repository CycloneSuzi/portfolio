<?php
/**
 * Searchresult php
 *
 * @category Php
 * @package  MyPackage
 * @author   Suzanne Townsend <s.e.t28@hotmail.com>
 * @license  no licence http://localhostegularExpression.php
 * @link     http://localhostegularExpression.php
 */
 
 
if (isset($_POST['InputTitle']) or isset($_POST['Inputgenre']) or isset($_POST['Inputrating']) or isset($_POST['Inputyear'])) {
    echo "<table style='border: solid 1px black;'>";
    echo "<tr><th>ID</th><th>Title</th><th>Studio</th><th>Status</th><th>Sound</th><th>Versions</th><th>RRP</th><th>Rating</th><th>Year</th><th>Genre</th><th>Aspect</th></tr>";

    /**
     * Searchresult php
     * 
     * Class Tablerows
     * 
     * @category Php
     * @package  MyPackage
     * @author   Suzanne Townsend <s.e.t28@hotmail.com>
     * @license  no licence http://localhostegularExpression.php
     * @link     http://localhostegularExpression.php
     */
    class TableRows extends RecursiveIteratorIterator 
    {

        /**
         * Functions 
         *
         * @param string $it 
         **/
        function __construct($it) 
        {
            parent::__construct($it, self::LEAVES_ONLY);
        }
        /**
         * Functions
         *
         * @return table
         **/
        function current() 
        {
            return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
        }
        /**
         * Functions
         *
         * @return table
         **/
        function beginChildren() 
        {
            echo "<tr>";
        }
        /**
         * Functions
         *
         * @return table
         **/
        function endChildren() 
        {
            echo "</tr>" . "\n";
        }
    } 

    
    $inputTitle = $_POST['InputTitle'];
    $inputgenre = $_POST['Inputgenre'];
    $inputrating = $_POST['Inputrating'];
    $inputyear = $_POST['Inputyear'];
    $username = 'root';
    $password = '';
    $result = '';
    if ($inputTitle AND $inputgenre AND $inputrating AND $inputyear) {

        try 
        {

            $conn = new PDO('mysql:host=localhost;dbname=quote_db', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies.movies WHERE title =:inputTitle AND rating =:inputrating AND genre =:inputgenre AND year_made =:inputyear');

            $stmt->bindParam(':inputTitle', $inputTitle, PDO::PARAM_STR);
            $stmt->bindParam(':inputrating', $inputrating, PDO::PARAM_STR);
            $stmt->bindParam(':inputgenre', $inputgenre, PDO::PARAM_STR);
            $stmt->bindParam(':inputyear', $inputyear, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";
    } else if ($inputrating AND $inputyear) {
        try 
        {

            $conn = new PDO('mysql:host=localhost;dbname=quote_db', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies.movies WHERE rating =:inputrating AND year_made =:inputyear');

            $stmt->bindParam(':inputrating', $inputrating, PDO::PARAM_STR);
            $stmt->bindParam(':inputyear', $inputyear, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";
    } else if ($inputgenre AND $inputyear) {
        try 
        {

            $conn = new PDO('mysql:host=localhost;dbname=quote_db', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies.movies WHERE genre =:inputgenre AND year_made =:inputyear');

            $stmt->bindParam(':inputgenre', $inputgenre, PDO::PARAM_STR);
            $stmt->bindParam(':inputyear', $inputyear, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";
    } else if ($inputgenre AND $inputrating) {
        try 
        {

            $conn = new PDO('mysql:host=localhost;dbname=quote_db', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies.movies WHERE rating =:inputrating AND genre =:inputgenre');

            $stmt->bindParam(':inputrating', $inputrating, PDO::PARAM_STR);
            $stmt->bindParam(':inputgenre', $inputgenre, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";
    } else if ($inputTitle) {

        try 
        {

            $conn = new PDO('mysql:host=localhost;dbname=quote_db', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies.movies where title = :inputTitle');

            $stmt->bindParam(':inputTitle', $inputTitle, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";

    } else if ($inputgenre) {

        try 
        {
            $conn = new PDO('mysql:host=localhost;dbname=movies', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies where genre = :inputgenre');
            $stmt->bindParam(':inputgenre', $inputgenre, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";

    } else if ($inputrating) {

        try 
        {
            $conn = new PDO('mysql:host=localhost;dbname=movies', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies where rating = :inputrating');
            $stmt->bindParam(':inputrating', $inputrating, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";

    } else if ($inputyear) {

        try 
        {
            $conn = new PDO('mysql:host=localhost;dbname=movies', $username, $password); 
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare('SELECT * FROM movies where year_made = :inputyear');
            $stmt->bindParam(':inputyear', $inputyear, PDO::PARAM_STR);
            $stmt->execute();
            $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
            if ($stmt->rowCount() == 0) {
                include "error.php";
    
            } else {
    
                foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                }
                $link_address= 'search_movies.php';
                echo "<a href='".$link_address."'>Back</a>";
            }
        }
        catch(PDOException $e) 
        {
            echo 'ERROR: ' . $e->getMessage();
        }
        $conn = null;
        echo "</table>";

    }
    /////END
} else {
    echo "Please choose your search option";
}
?>