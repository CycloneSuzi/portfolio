<?php
/**
 * error php
 *
 * @category Php
 * @package  MyPackage
 * @author   Suzanne Townsend <s.e.t28@hotmail.com>
 * @license  no licence http://localhostegularExpression.php
 * @link     http://localhostegularExpression.php
 */
 
 

        echo "No results where found.";
        $link_address= 'search_movies.php';
        echo "<a href='".$link_address."'>Back</a>";

?>