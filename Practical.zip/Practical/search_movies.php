<html>
<head> <H1> Search Movies </H1></head><br>
<br>
<body>
"Search with any mix of Title, Genre, Rating and/or Year
<br>
<br>
<br>
<form action="searchresult.php" method="post">
Search by title: <input type="text" name="InputTitle"><br>
<form action="searchresult.php" method="post">
Search by genre: <input type="text" name="Inputgenre"><br>
<form action="searchresult.php" method="post">
Search by rating: <input type="text" name="Inputrating"><br>
<form action="searchresult.php" method="post">
Search by year: <input type="text" name="Inputyear"><br>
<input type="submit">
</form>
</body>
<?php
/**
 * Search_movies php
 *
 * @category Php
 * @package  MyPackage
 * @author   Suzanne Townsend <s.e.t28@hotmail.com>
 * @license  no licence http://localhostegularExpression.php
 * @link     http://localhostegularExpression.php
 */
 
 
$link_address= 'index.html';
echo "<a href='".$link_address."'>Back</a>";
?>

</html>