﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Virada_Games
{

    public partial class Form1 : Form
    {

        Item ni = new Item();
        Customer cu = new Customer();
        Transactions tr = new Transactions();
        int nextId = 1;
        int nextcId = 1;
        bool isGame = false;
        bool isPlatform = false;
        bool isAccessory = false;
        public static ArrayList a1 = new ArrayList();
        public static ArrayList a2 = new ArrayList();
        public static ArrayList a3 = new ArrayList();
        public static ArrayList a4 = new ArrayList();
        public static ArrayList a5 = new ArrayList();
        public static ArrayList a6 = new ArrayList();
        public static ArrayList a7 = new ArrayList();
        public static ArrayList a8 = new ArrayList();
        public static ArrayList a9 = new ArrayList();
        public static ArrayList b1 = new ArrayList();
        public static ArrayList b2 = new ArrayList();
        public static ArrayList b3 = new ArrayList();
        public static ArrayList b4 = new ArrayList();
        public static ArrayList b5 = new ArrayList();
        public static ArrayList b9 = new ArrayList();
        public static ArrayList c1 = new ArrayList();
        public static ArrayList c2 = new ArrayList();
        public static ArrayList c3 = new ArrayList();
        public static ArrayList c4 = new ArrayList();
        public static ArrayList c5 = new ArrayList();
        public static ArrayList c6 = new ArrayList();
        public static ArrayList c9 = new ArrayList();
        public Form1()
        {


            InitializeComponent();
            Clear();
            DecodeitemsFile(GetitemsFile());
            DecodecustFile(GetcustFile());
            DecodetransFile(GettransFile());
            RefreshPlist();
            RefreshClist();
            RefreshTlist(); 
            nextCID();
            nextPID();
            dateTimePicker1.Value = DateTime.Now;
            date = dateTimePicker1.Value.Date.ToString("dd/MM/yyyy");


        }
        public string pID
        {
            get { return tbPID.Text; }
            set { tbPID.Text = value; }
        }
        public string desc
        {
            get { return tbDesc.Text; }
            set { tbDesc.Text = value; }
        }
        public int stockQ
        {
            get;
            set;

        }
        public double retPrice
        {
            get;
            set;
        }
        public string publisher
        {
            get { return tbPublisher.Text; }
            set { tbPublisher.Text = value; }
        }
        public string mediaType
        {
            get { return tbMedia.Text; }
            set { tbMedia.Text = value; }

        }
        public string modelNo
        {
            get { return tbModelNo.Text; }
            set { tbModelNo.Text = value; }

        }
        public string platform
        {
            get { return tbPlatform.Text; }
            set { tbPlatform.Text = value; }

        }
        public string cID
        {
            get { return tbCustID.Text; }
            set { tbCustID.Text = value; }
        }
        public string famName
        {
            get { return tbFamName.Text; }
            set { tbFamName.Text = value; }
        }
        public int mobNum
        {
            get;
            set;

        }
        public string firstName
        {
            get { return tbFirstName.Text; }
            set { tbFirstName.Text = value; }
        }
        public string email
        {
            get { return tbEmail.Text; }
            set { tbEmail.Text = value; }
        }
        public string custTID
        {
            get { return tbTCID.Text; }
            set { tbTCID.Text = value; }
        }
        public string tPID
        {
            get { return tbTPID.Text; }
            set { tbTPID.Text = value; }
        }
        public int quantity { get; set; }

        public double retTPrice { get; set; }

        public double wholesale { get; set; }

        public string date
        { get; set; }

        public void nextPID()
        {
            nextId = lbProd.Items.Count + 1;
            tbPID.Text = nextId.ToString().PadLeft(5, '0');
        }

        public void nextCID()
        {
            nextcId = lbCust.Items.Count + 1;
            tbCustID.Text = "C" + nextcId.ToString().PadLeft(3, '0');
        }


        private void button1_Click(object sender, EventArgs e)
        {
            a1.Clear(); a2.Clear(); a3.Clear(); a4.Clear(); a5.Clear(); a6.Clear(); a7.Clear(); a8.Clear(); a9.Clear();
            int stockQ;

            if (string.IsNullOrEmpty(tbPublisher.Text) || string.IsNullOrEmpty(tbMedia.Text))
            {
                isGame = false;
            }
            else
            {
                isGame = true;
            }
            if (string.IsNullOrEmpty(tbModelNo.Text))
            {
                isPlatform = false;
            }
            else
            {
                isPlatform = true;
            }

            if (string.IsNullOrEmpty(tbPlatform.Text))
            {
                isAccessory = false;
            }
            else
            {
                isAccessory = true;
            }
        

            
            if (!int.TryParse(tbStock.Text, out stockQ))
            {
                MessageBox.Show("Stock Quantity is a number only field");

            }

            double retPrice;
            if (!double.TryParse(tbRetPrice.Text, out retPrice))
            {
                MessageBox.Show("The Retail Price is a number only field");

            }

            Item ni = new Item(pID, desc, stockQ, retPrice, publisher, mediaType, modelNo, platform);

            if (!isGame && !isPlatform && !isAccessory)
            {
                MessageBox.Show("Insufficient Data Entered, Please enter relevant data and try again.");
            }
            else if ((isGame || isPlatform || isAccessory) == true)
            { 
                ni.AddProd();
                ni.SaveAll();
                Clear();
                a1.Clear(); a2.Clear(); a3.Clear(); a4.Clear(); a5.Clear(); a6.Clear(); a7.Clear(); a8.Clear();
                lbCust.Items.Clear();
                lbProd.Items.Clear();
                lbTrans.Items.Clear();
                DecodeitemsFile(GetitemsFile());
                DecodecustFile(GetcustFile());
                DecodetransFile(GettransFile());
                RefreshPlist();
                RefreshClist();
                RefreshTlist();
                nextCID();
                nextPID();


            }
        }


        
        public void Clear()
        {
            nextPID();
            tbDesc.Clear();
            tbStock.Clear();
            tbRetPrice.Clear();
            tbPublisher.Clear();
            tbMedia.Clear();
            tbModelNo.Clear();
            tbPlatform.Clear();
            tbCustID.Clear();
            lbProd.Items.Clear();
            tbFamName.Clear();
            tbFirstName.Clear();
            tbEmail.Clear();
            tbMobile.Clear();
            lbCust.Items.Clear();
            tbTCID.Clear();
            tbTPID.Clear();
            tbTQuantity.Clear();
            tbTRetPrice.Clear();
            tbTWholesale.Clear();
            dateTimePicker1.Value = DateTime.Now;
            lbTrans.Items.Clear();


        }
        public string GetitemsFile()
        {
            return string.Format("{0}\\{1}", Environment.CurrentDirectory, "items.dat");
        }
        public void DecodeitemsFile(string loc)
        {

            a1.Clear(); a2.Clear(); a3.Clear(); a4.Clear(); a5.Clear(); a6.Clear(); a7.Clear(); a8.Clear();
            string data = String.Empty;
            if (File.Exists(loc))
            {
                using (FileStream fs = new FileStream(loc, FileMode.Open))
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        byte[] bin = br.ReadBytes(Convert.ToInt32(fs.Length));
                        data = Encoding.UTF8.GetString(bin);
                    }

                    if (data.Length > 1)
                    {
                        data = data.Substring(1);
                        string[] temp = data.Split('Ç');
                        foreach (string s in temp)
                        {
                            string[] temp2 = s.Split('Æ');
                            if (temp2.Length > 1)
                            {
                                a1.Add(temp2.GetValue(0));
                                a2.Add(temp2.GetValue(1));
                                a3.Add(temp2.GetValue(2));
                                a4.Add(temp2.GetValue(3));
                                a5.Add(temp2.GetValue(4));
                                a6.Add(temp2.GetValue(5));
                                a7.Add(temp2.GetValue(6));
                                a8.Add(temp2.GetValue(7));
                            }
                        }
                    }
                }
            }
        }

        public void RefreshPlist()
        {
            int i = 0;
            foreach (string s in a1)
            {
                lbProd.Items.Add(string.Format("{0}, {1},", a1[i], a2[i]));
                i++;
            }
        }

        public void RefreshClist()
        {
            int i = 0;
            foreach (string s in b1)
            {
                lbCust.Items.Add(string.Format("{0}, {1}, {2}", b1[i], b3[i], b2[i]));
                i++;
            }
        }
        public void RefreshTlist()
        {
            int i = 0;
            foreach (string s in c1)
            {
                lbTrans.Items.Add(c1[i] + " " + c2[i] + ", " + c3[i] + ", " + c6[i]);
                i++;
            }
        }

        private void lbProd_SelectedValueChanged(object sender, EventArgs e)
        {
            int i = lbProd.SelectedIndex;

            tbPID.Text = a1[i].ToString();
            tbDesc.Text = a2[i].ToString();
            tbStock.Text = a3[i].ToString();
            tbRetPrice.Text = a4[i].ToString();
            tbPublisher.Text = a5[i].ToString();
            tbMedia.Text = a6[i].ToString();
            tbModelNo.Text = a7[i].ToString();
            tbPlatform.Text = a8[i].ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            b1.Clear(); b2.Clear(); b3.Clear(); b4.Clear(); b5.Clear(); b9.Clear();
            int mobNum;
            if (string.IsNullOrEmpty(tbCustID.Text) || string.IsNullOrEmpty(tbFamName.Text) || string.IsNullOrEmpty(tbFirstName.Text) || string.IsNullOrEmpty(tbEmail.Text) || string.IsNullOrEmpty(tbMobile.Text))
            {
                MessageBox.Show("Not all appropriate fields have data. Please check your data entry and try again");
            }
            else
            {
                if (!int.TryParse(tbMobile.Text, out mobNum))
                {
                    MessageBox.Show("Mobile Number is a number only field");

                }
                else
                {
                    Customer cu = new Customer(cID, famName, firstName, email, mobNum);


                    
                    cu.AddCust();
                    cu.SaveAll();
                    lbCust.Items.Clear();
                    lbProd.Items.Clear();
                    lbTrans.Items.Clear();
                    b1.Clear(); b2.Clear(); b3.Clear(); b4.Clear(); b5.Clear(); b9.Clear();
                    lbCust.Items.Clear();
                    lbProd.Items.Clear();
                    lbTrans.Items.Clear();
                    DecodeitemsFile(GetitemsFile());
                    DecodecustFile(GetcustFile());
                    DecodetransFile(GettransFile());
                    RefreshPlist();
                    RefreshClist();
                    RefreshTlist();
                    nextCID();
                    nextPID();
                }
            }
        }
        private void lbCust_SelectedValueChange(object sender, EventArgs e)
        {
            int i = lbCust.SelectedIndex;

            tbCustID.Text = b1[i].ToString();
            tbFamName.Text = b2[i].ToString();
            tbFirstName.Text = b3[i].ToString();
            tbEmail.Text = b4[i].ToString();
            tbMobile.Text = b5[i].ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            c1.Clear(); c2.Clear(); c3.Clear(); c4.Clear(); c5.Clear(); c6.Clear(); c9.Clear();
            int quantity;
            MessageBox.Show(date);

            if (string.IsNullOrEmpty(tbTCID.Text) || string.IsNullOrEmpty(tbTPID.Text) || string.IsNullOrEmpty(tbTQuantity.Text) || string.IsNullOrEmpty(tbTRetPrice.Text) || string.IsNullOrEmpty(tbTWholesale.Text) || string.IsNullOrEmpty(date))
                {
                    MessageBox.Show("Not all appropriate fields have data. Please check your data entry and try again");
                }
                else
                {
                    if (!int.TryParse(tbTQuantity.Text, out quantity))
                    {
                        MessageBox.Show("Quantity is a number only field");

                    }
                    double retTPrice;
                    if (!double.TryParse(tbTRetPrice.Text, out retTPrice))
                    {
                        MessageBox.Show("Please enter price numerically to 2 decimal places.");
                    }
                    double wholesale;
                    if (!double.TryParse(tbTWholesale.Text, out wholesale))
                    {
                        MessageBox.Show("Quantity is a number only field");

                    }
                    Transactions tr = new Transactions(custTID, tPID, quantity, retTPrice, wholesale, date);



                    tr.AddTrans();
                    tr.SaveAll();
                    Clear();
                    c1.Clear(); c2.Clear(); c3.Clear(); c4.Clear(); c5.Clear(); c6.Clear(); c9.Clear();
                    lbCust.Items.Clear();
                    lbProd.Items.Clear();
                    lbTrans.Items.Clear();
                    DecodeitemsFile(GetitemsFile());
                    DecodecustFile(GetcustFile());
                    DecodetransFile(GettransFile());
                    RefreshPlist();
                    RefreshClist();
                    RefreshTlist();
                   nextCID();
                   nextPID();
            }
            }


          
        
        private void lbTrans_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = lbTrans.SelectedIndex;

            tbTCID.Text = c1[i].ToString();
            tbTPID.Text = c2[i].ToString();
            tbTQuantity.Text = c3[i].ToString();
            tbTRetPrice.Text = c4[i].ToString();
            tbTWholesale.Text = c5[i].ToString();
            dateTimePicker1.Value = DateTime.Parse(c6[i].ToString());
        }

        public void DecodecustFile(string loc)
        {

            b1.Clear(); b2.Clear(); b3.Clear(); b4.Clear(); b5.Clear();
            string data = String.Empty;
            if (File.Exists(loc))
            {
                using (FileStream fs = new FileStream(loc, FileMode.Open))
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        byte[] bin = br.ReadBytes(Convert.ToInt32(fs.Length));
                        data = Encoding.UTF8.GetString(bin);
                    }

                    if (data.Length > 1)
                    {
                        data = data.Substring(1);
                        string[] temp = data.Split('Ç');
                        foreach (string s in temp)
                        {

                            string[] temp2 = s.Split('Æ');
                            if (temp2.Length > 1)
                            {
                                b1.Add(temp2.GetValue(0));
                                b2.Add(temp2.GetValue(1));
                                b3.Add(temp2.GetValue(2));
                                b4.Add(temp2.GetValue(3));
                                b5.Add(temp2.GetValue(4));

                            }
                        }
                    }
                }
            }
        }

        public string GetcustFile()
        {
            return string.Format("{0}\\{1}", Environment.CurrentDirectory, "customers.dat");
        }

        

        public void DecodetransFile(string loc)
        {

            c1.Clear(); c2.Clear(); c3.Clear(); c4.Clear(); c5.Clear(); c6.Clear();
            string data = String.Empty;
            if (File.Exists(loc))
            {
                using (FileStream fs = new FileStream(loc, FileMode.Open))
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        byte[] bin = br.ReadBytes(Convert.ToInt32(fs.Length));
                        data = Encoding.UTF8.GetString(bin);
                    }

                    if (data.Length > 1)
                    {
                        data = data.Substring(1);
                        string[] temp = data.Split('Ç');
                        foreach (string s in temp)
                        {

                            string[] temp2 = s.Split('Æ');
                            if (temp2.Length > 1)
                            {
                                c1.Add(temp2.GetValue(0));
                                c2.Add(temp2.GetValue(1));
                                c3.Add(temp2.GetValue(2));
                                c4.Add(temp2.GetValue(3));
                                c5.Add(temp2.GetValue(4));
                                c6.Add(temp2.GetValue(5));
                            }
                        }
                    }
                }
            }
        }


        

        public string GettransFile()
        {
            return string.Format("{0}\\{1}", Environment.CurrentDirectory, "transactions.dat");
        }

    }
    }


    

