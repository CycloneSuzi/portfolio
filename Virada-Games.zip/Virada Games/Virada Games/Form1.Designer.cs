﻿namespace Virada_Games
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbPID = new System.Windows.Forms.TextBox();
            this.tbDesc = new System.Windows.Forms.TextBox();
            this.tbStock = new System.Windows.Forms.TextBox();
            this.tbRetPrice = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbMedia = new System.Windows.Forms.TextBox();
            this.tbPublisher = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbModelNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbPlatform = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lbProd = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbMobile = new System.Windows.Forms.TextBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.tbFamName = new System.Windows.Forms.TextBox();
            this.tbCustID = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tbTWholesale = new System.Windows.Forms.TextBox();
            this.tbTRetPrice = new System.Windows.Forms.TextBox();
            this.tbTQuantity = new System.Windows.Forms.TextBox();
            this.tbTPID = new System.Windows.Forms.TextBox();
            this.tbTCID = new System.Windows.Forms.TextBox();
            this.lbCust = new System.Windows.Forms.ListBox();
            this.lbTrans = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Stock Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Retail Price";
            // 
            // tbPID
            // 
            this.tbPID.Location = new System.Drawing.Point(94, 19);
            this.tbPID.Name = "tbPID";
            this.tbPID.Size = new System.Drawing.Size(100, 20);
            this.tbPID.TabIndex = 4;
            this.toolTip1.SetToolTip(this.tbPID, "Enter Idetifying code of Product");
            // 
            // tbDesc
            // 
            this.tbDesc.Location = new System.Drawing.Point(94, 52);
            this.tbDesc.Name = "tbDesc";
            this.tbDesc.Size = new System.Drawing.Size(100, 20);
            this.tbDesc.TabIndex = 5;
            this.toolTip1.SetToolTip(this.tbDesc, "Discription of product");
            // 
            // tbStock
            // 
            this.tbStock.Location = new System.Drawing.Point(94, 93);
            this.tbStock.Name = "tbStock";
            this.tbStock.Size = new System.Drawing.Size(100, 20);
            this.tbStock.TabIndex = 6;
            this.toolTip1.SetToolTip(this.tbStock, "Quantity of stock on hand");
            // 
            // tbRetPrice
            // 
            this.tbRetPrice.Location = new System.Drawing.Point(94, 130);
            this.tbRetPrice.Name = "tbRetPrice";
            this.tbRetPrice.Size = new System.Drawing.Size(100, 20);
            this.tbRetPrice.TabIndex = 7;
            this.toolTip1.SetToolTip(this.tbRetPrice, "End sale price of product");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbPID);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbRetPrice);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbStock);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbDesc);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(26, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 178);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Item Info";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbMedia);
            this.groupBox2.Controls.Add(this.tbPublisher);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(26, 236);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Games";
            // 
            // tbMedia
            // 
            this.tbMedia.Location = new System.Drawing.Point(94, 74);
            this.tbMedia.Name = "tbMedia";
            this.tbMedia.Size = new System.Drawing.Size(100, 20);
            this.tbMedia.TabIndex = 3;
            this.toolTip1.SetToolTip(this.tbMedia, "What format is the game in?");
            // 
            // tbPublisher
            // 
            this.tbPublisher.Location = new System.Drawing.Point(94, 12);
            this.tbPublisher.Name = "tbPublisher";
            this.tbPublisher.Size = new System.Drawing.Size(100, 20);
            this.tbPublisher.TabIndex = 2;
            this.toolTip1.SetToolTip(this.tbPublisher, "Name of Game publisher");
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Media Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(0, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Publisher";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbModelNo);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Location = new System.Drawing.Point(26, 373);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 80);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Platforms";
            // 
            // tbModelNo
            // 
            this.tbModelNo.Location = new System.Drawing.Point(94, 21);
            this.tbModelNo.Name = "tbModelNo";
            this.tbModelNo.Size = new System.Drawing.Size(100, 20);
            this.tbModelNo.TabIndex = 1;
            this.toolTip1.SetToolTip(this.tbModelNo, "Model number of platform");
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Model Number";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tbPlatform);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Location = new System.Drawing.Point(26, 489);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 78);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Accessories";
            // 
            // tbPlatform
            // 
            this.tbPlatform.Location = new System.Drawing.Point(94, 27);
            this.tbPlatform.Name = "tbPlatform";
            this.tbPlatform.Size = new System.Drawing.Size(100, 20);
            this.tbPlatform.TabIndex = 1;
            this.toolTip1.SetToolTip(this.tbPlatform, "What platform does this accessory work with?");
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Platform Type";
            // 
            // lbProd
            // 
            this.lbProd.FormattingEnabled = true;
            this.lbProd.Location = new System.Drawing.Point(253, 106);
            this.lbProd.Name = "lbProd";
            this.lbProd.Size = new System.Drawing.Size(162, 459);
            this.lbProd.TabIndex = 12;
            this.lbProd.SelectedValueChanged += new System.EventHandler(this.lbProd_SelectedValueChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(253, 63);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(275, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 31);
            this.label5.TabIndex = 14;
            this.label5.Text = "Products";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(551, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 33);
            this.label6.TabIndex = 15;
            this.label6.Text = "Customers";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tbMobile);
            this.groupBox5.Controls.Add(this.tbEmail);
            this.groupBox5.Controls.Add(this.tbFirstName);
            this.groupBox5.Controls.Add(this.tbFamName);
            this.groupBox5.Controls.Add(this.tbCustID);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Location = new System.Drawing.Point(504, 47);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(231, 216);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Customer Info";
            // 
            // tbMobile
            // 
            this.tbMobile.Location = new System.Drawing.Point(110, 181);
            this.tbMobile.Name = "tbMobile";
            this.tbMobile.Size = new System.Drawing.Size(100, 20);
            this.tbMobile.TabIndex = 9;
            this.toolTip1.SetToolTip(this.tbMobile, "Mobile phone number of customer");
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(110, 143);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(100, 20);
            this.tbEmail.TabIndex = 8;
            this.toolTip1.SetToolTip(this.tbEmail, "Customer Email");
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(110, 111);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(100, 20);
            this.tbFirstName.TabIndex = 7;
            this.toolTip1.SetToolTip(this.tbFirstName, "First name of cuntstomer");
            // 
            // tbFamName
            // 
            this.tbFamName.Location = new System.Drawing.Point(110, 74);
            this.tbFamName.Name = "tbFamName";
            this.tbFamName.Size = new System.Drawing.Size(100, 20);
            this.tbFamName.TabIndex = 6;
            this.toolTip1.SetToolTip(this.tbFamName, "family name of customer");
            // 
            // tbCustID
            // 
            this.tbCustID.Location = new System.Drawing.Point(110, 33);
            this.tbCustID.Name = "tbCustID";
            this.tbCustID.Size = new System.Drawing.Size(100, 20);
            this.tbCustID.TabIndex = 5;
            this.toolTip1.SetToolTip(this.tbCustID, "ID of customer");
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 189);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Mobile";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 150);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(32, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Email";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 111);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "First Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 74);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Family Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "CustID";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dateTimePicker1);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.tbTWholesale);
            this.groupBox6.Controls.Add(this.tbTRetPrice);
            this.groupBox6.Controls.Add(this.tbTQuantity);
            this.groupBox6.Controls.Add(this.tbTPID);
            this.groupBox6.Controls.Add(this.tbTCID);
            this.groupBox6.Location = new System.Drawing.Point(504, 310);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(231, 267);
            this.groupBox6.TabIndex = 17;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Transactions";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 213);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 13);
            this.label22.TabIndex = 11;
            this.label22.Text = "Date";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(19, 185);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(81, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "Wholesale Cost";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 147);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 13);
            this.label20.TabIndex = 9;
            this.label20.Text = "Retail Price";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 108);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "Quantity";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(16, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Product ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 13);
            this.label17.TabIndex = 6;
            this.label17.Text = "CustID";
            // 
            // tbTWholesale
            // 
            this.tbTWholesale.Location = new System.Drawing.Point(110, 179);
            this.tbTWholesale.Name = "tbTWholesale";
            this.tbTWholesale.Size = new System.Drawing.Size(100, 20);
            this.tbTWholesale.TabIndex = 4;
            this.toolTip1.SetToolTip(this.tbTWholesale, "Cost to company to supply item");
            // 
            // tbTRetPrice
            // 
            this.tbTRetPrice.Location = new System.Drawing.Point(109, 140);
            this.tbTRetPrice.Name = "tbTRetPrice";
            this.tbTRetPrice.Size = new System.Drawing.Size(100, 20);
            this.tbTRetPrice.TabIndex = 3;
            this.toolTip1.SetToolTip(this.tbTRetPrice, "Price at time of sale");
            // 
            // tbTQuantity
            // 
            this.tbTQuantity.Location = new System.Drawing.Point(109, 101);
            this.tbTQuantity.Name = "tbTQuantity";
            this.tbTQuantity.Size = new System.Drawing.Size(100, 20);
            this.tbTQuantity.TabIndex = 2;
            this.toolTip1.SetToolTip(this.tbTQuantity, "Quantity of product customer has purchased");
            // 
            // tbTPID
            // 
            this.tbTPID.Location = new System.Drawing.Point(109, 59);
            this.tbTPID.Name = "tbTPID";
            this.tbTPID.Size = new System.Drawing.Size(100, 20);
            this.tbTPID.TabIndex = 1;
            this.toolTip1.SetToolTip(this.tbTPID, "ID of Product");
            // 
            // tbTCID
            // 
            this.tbTCID.Location = new System.Drawing.Point(109, 20);
            this.tbTCID.Name = "tbTCID";
            this.tbTCID.Size = new System.Drawing.Size(100, 20);
            this.tbTCID.TabIndex = 0;
            this.toolTip1.SetToolTip(this.tbTCID, "Id of Customer, C000 if unknown");
            // 
            // lbCust
            // 
            this.lbCust.FormattingEnabled = true;
            this.lbCust.Location = new System.Drawing.Point(785, 83);
            this.lbCust.Name = "lbCust";
            this.lbCust.Size = new System.Drawing.Size(181, 173);
            this.lbCust.TabIndex = 18;
            this.lbCust.SelectedIndexChanged += new System.EventHandler(this.lbCust_SelectedValueChange);
            // 
            // lbTrans
            // 
            this.lbTrans.FormattingEnabled = true;
            this.lbTrans.Location = new System.Drawing.Point(785, 314);
            this.lbTrans.Name = "lbTrans";
            this.lbTrans.Size = new System.Drawing.Size(180, 251);
            this.lbTrans.TabIndex = 19;
            this.lbTrans.SelectedIndexChanged += new System.EventHandler(this.lbTrans_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(785, 47);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(180, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(785, 275);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(180, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(539, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(195, 33);
            this.label7.TabIndex = 22;
            this.label7.Text = "Transactions";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(110, 208);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 601);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lbTrans);
            this.Controls.Add(this.lbCust);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbProd);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbPID;
        private System.Windows.Forms.TextBox tbDesc;
        private System.Windows.Forms.TextBox tbStock;
        private System.Windows.Forms.TextBox tbRetPrice;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox lbProd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ListBox lbCust;
        private System.Windows.Forms.ListBox lbTrans;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbMedia;
        private System.Windows.Forms.TextBox tbPublisher;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbModelNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbPlatform;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbMobile;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.TextBox tbFamName;
        private System.Windows.Forms.TextBox tbCustID;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbTWholesale;
        private System.Windows.Forms.TextBox tbTRetPrice;
        private System.Windows.Forms.TextBox tbTQuantity;
        private System.Windows.Forms.TextBox tbTPID;
        private System.Windows.Forms.TextBox tbTCID;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}

