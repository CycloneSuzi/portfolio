﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Virada_Games
{
    class Customer
    {
        
        public ArrayList a1 = new ArrayList();
        public ArrayList a2 = new ArrayList();
        public ArrayList a3 = new ArrayList();
        public ArrayList a4 = new ArrayList();
        public ArrayList a5 = new ArrayList();
        public ArrayList a9 = new ArrayList();

        
        string cID;
        string famName;
        string firstName;
        string email;
        int mobNum;

            public string CustomerID { get { return cID; } set { cID = value; } }
            public string FamName { get { return famName; } set { famName = value; } }
            public string FirstName { get { return firstName; } set { firstName = value; } }
            public string Email { get { return email; } set { email = value; } }
            public int MobNum { get { return mobNum; } set { mobNum = value; } }

        public Customer()
        {

        }

        public Customer(string cID, string famName, string firstName, string email, int mobNum)
        {
            this.cID = cID;
            this.famName = famName;
            this.firstName = firstName;
            this.email = email;
            this.mobNum = mobNum;

        }

        public void AddCust()
        {
            //MessageBox.Show(modelNo);     //test variable passthrough


            Form1.b1.Add(cID);
            Form1.b2.Add(famName);
            Form1.b3.Add(firstName);
            Form1.b4.Add(email);
            Form1.b5.Add(mobNum);



        }

        public string GetFile()
        {
            return string.Format("{0}\\{1}", Environment.CurrentDirectory, "customers.dat");
        }
        

        public void Search(string val)
        {
            int i = 0;
            foreach (string it in Form1.b1)
            {
                if (String.Compare(it, val, true) == 0)
                {
                    MessageBox.Show("Customer ID already exists");

                    return;
                }
                i++;
            }

        }

        public virtual void SaveAll()
        {
              MessageBox.Show(Form1.b1[0].ToString());        //test variable passthrough
            int i = 0;
            foreach (string a in Form1.b1)
            {
                Form1.b9.Add(string.Format("{0}Æ{1}Æ{2}Æ{3}Æ{4}", Form1.b1[i], Form1.b2[i], Form1.b3[i], Form1.b4[i], Form1.b5[i]));
                i++;
            }
            Form1.b9.Sort();
            StringBuilder sb = new StringBuilder();

            foreach (string s in Form1.b9)
            {
                sb.AppendFormat("{0}Ç", s);
            }
            using (BinaryWriter w = new BinaryWriter(File.Open(GetFile(), FileMode.Append)))
            {
                w.Write(sb.ToString());
                w.Close();
            }
            Form1.b1.Clear(); Form1.b2.Clear(); Form1.b3.Clear(); Form1.b4.Clear(); Form1.b5.Clear(); 
        }


    }
    

    }

