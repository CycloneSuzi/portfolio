﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Virada_Games
{
    class Transactions
    {

        public ArrayList a1 = new ArrayList();
        public ArrayList a2 = new ArrayList();
        public ArrayList a3 = new ArrayList();
        public ArrayList a4 = new ArrayList();
        public ArrayList a5 = new ArrayList();
        public ArrayList a6 = new ArrayList();

        ArrayList a9 = new ArrayList();
        
        string custTID;
        string tPid;
        int quantity;
        double retTransPrice;
        double wholesale;
        string date;



        public string custTransID { get { return custTID; } set { custTID = value; } }
        public string TPID { get { return tPid; } set { tPid = value; } }
        public int stockQuantity { get { return quantity; } set { quantity = value; } }
        public double retTPrice { get { return retTransPrice; } set { retTransPrice = value; } }
        public double Wholesale { get { return wholesale; } set { wholesale = value; } }
        public string Date { get { return date; } set { date = value; } }


        public Transactions()
        {

        }

        public Transactions(string custTID, string TPid, int quantity, double retTPrice, double wholesale, string date)
        {
            this.custTID = custTID;
            this.tPid = TPid;
            this.quantity = quantity;
            this.retTPrice = retTPrice;
            this.wholesale = wholesale;
            this.date = date;

        }

        public void AddTrans()
        {

            Form1.c1.Add(custTID);
            Form1.c2.Add(TPID);
            Form1.c3.Add(quantity);
            Form1.c4.Add(retTPrice);
            Form1.c5.Add(wholesale);
            Form1.c6.Add(date);

        }
        public string GetFile()
        {
            return string.Format("{0}\\{1}", Environment.CurrentDirectory, "transactions.dat");
        }
        

        
        public virtual void SaveAll()
        {
            //  MessageBox.Show(a7[0].ToString());        //test variable passthrough
            int i = 0;
            foreach (string a in Form1.c1)
            {
                Form1.c9.Add(string.Format("{0}Æ{1}Æ{2}Æ{3}Æ{4}Æ{5}", Form1.c1[i], Form1.c2[i], Form1.c3[i], Form1.c4[i], Form1.c5[i], Form1.c6[i]));
                i++;
            }
            Form1.c9.Sort();
            StringBuilder sb = new StringBuilder();

            foreach (string s in Form1.c9)
            {
                sb.AppendFormat("{0}Ç", s);
            }
            using (BinaryWriter w = new BinaryWriter(File.Open(GetFile(), FileMode.Append)))
            {
                w.Write(sb.ToString());
            }

        }


    }
}

