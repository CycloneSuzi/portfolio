﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Virada_Games
{
    
        
        public class Item
        {
        
        
       
        string pID, desc;
        int stockQ;
        double retPrice;
        string publisher;
        string mediaType;
        string modelNo;
        string platform;


            public string productID { get { return pID; } set { pID = value; } }
            public string description { get { return desc; } set { desc = value; } }
            public int stockQuantity { get { return stockQ; } set { stockQ = value; } }
            public double retailPrice { get { return retPrice; } set { retPrice = value; } }
            public string Publisher { get { return publisher; } set { publisher = value; } }
            public string MediaType { get { return mediaType; } set { mediaType = value; } }
            public string ModelNo { get { return modelNo; } set { modelNo = value; } }
            public string Accessory { get { return platform; } set { platform = value; } }

        public Item()
        {

        }

        public Item(string pID, string desc, int stockQ, double retPrice, string publisher, string mediaType, string modelNo, string platform)
            {
                this.pID = pID;
                this.desc = desc;
                this.stockQ = stockQ;
                this.retPrice = retPrice;
                this.publisher = publisher;
                this.mediaType = mediaType;
                this.modelNo = modelNo;
                this.platform = platform;
        }

        


        
        
        public void AddProd()
        {
            //MessageBox.Show(modelNo);     //test variable passthrough
            if ((String.IsNullOrEmpty(publisher)) && String.IsNullOrEmpty(mediaType))
            {
                publisher = "n/a";
                mediaType = "n/a";

            }
            if (String.IsNullOrEmpty(modelNo))
            {
                modelNo = "n/a";
            }

            if (String.IsNullOrEmpty(platform))
            {
                platform = "n/a";
            }

            Form1.a1.Add(pID);
            Form1.a2.Add(desc);
            Form1.a3.Add(stockQ);
            Form1.a4.Add(retPrice);
            Form1.a5.Add(publisher);
            Form1.a6.Add(mediaType);
            Form1.a7.Add(modelNo);
            Form1.a8.Add(platform);


        }

        public void Search(string val)
        {
            int i = 0;
            foreach (string it in Form1.a1)
            {
                if (String.Compare(it, val, true) == 0)
                {
                    MessageBox.Show("Product ID already exists");

                    return;
                }
                i++;
            }

        }

        public virtual void SaveAll()
        {
          //  MessageBox.Show(a7[0].ToString());        //test variable passthrough
            int i = 0;
            foreach (string a in Form1.a1)
            {
                Form1.a9.Add(string.Format("{0}Æ{1}Æ{2}Æ{3}Æ{4}Æ{5}Æ{6}Æ{7}", Form1.a1[i], Form1.a2[i], Form1.a3[i], Form1.a4[i], Form1.a5[i], Form1.a6[i], Form1.a7[i], Form1.a8[i]));
                i++;
            }
            Form1.a9.Sort();
            StringBuilder sb = new StringBuilder();

            foreach (string s in Form1.a9)
            {
                sb.AppendFormat("{0}Ç", s);
            }
            using (BinaryWriter w = new BinaryWriter(File.Open(GetFile(), FileMode.Append)))
            {
                w.Write(sb.ToString());
                w.Close();
            }
            Form1.a1.Clear(); Form1.a2.Clear(); Form1.a3.Clear(); Form1.a4.Clear(); Form1.a5.Clear(); Form1.a6.Clear(); Form1.a7.Clear(); Form1.a8.Clear();
        }

        public string GetFile()
        {
            return string.Format("{0}\\{1}", Environment.CurrentDirectory, "items.dat");
        }
    }
    

}

