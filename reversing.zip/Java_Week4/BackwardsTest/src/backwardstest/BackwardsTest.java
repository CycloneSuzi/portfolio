/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backwardstest;

import java.util.ArrayList;

/**
 *
 * @author Suzanne Townsend. Purpose: JP_3-1. Date: 2017/08/16.
 */
public class BackwardsTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Question 1
        String strBackwards = "";
        String str = "sdrawkcaB eM daeR";
        for (int i = str.length() - 1; i >= 0; i--) {
            strBackwards += str.substring(i, i + 1);
        }
        System.out.println(strBackwards);
        
        //Question 4 & 5 Intiation.
        toString("Reverse My Words");
        stringBuild();
        
    }

    public static String toString(String str) {
        
        //Question 4
        String reverse = " ";
        for (int i = str.length() - 1; i >= 0; i--) {
            reverse += str.charAt(i);
        }
        System.out.println(reverse);
        return "Reveresed String: " + reverse;
    }
    public static void stringBuild() {
        
        //Question 5
        String v = "reverse this sentence";
        StringBuilder sbuild = new StringBuilder(v);
        System.out.println(sbuild.reverse());

    }
    
    }


