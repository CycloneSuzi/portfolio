/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionstest;

import java.io.FileInputStream;
import java.io.InputStream;

/**
 *
 * @author Suzanne Townsend. Purpose: JP_3-1. Date: 2017/08/16.
 */
public class MyException extends Exception {
    
    public MyException(){
    super();
    String message = "Please Create File.";
    }
    
    public MyException(String message) {
        super(message);
    
}
}
   
