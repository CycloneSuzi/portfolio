/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionstest;

import java.io.FileInputStream;
import java.io.InputStream;

/**
 *
 * @author Suzanne Townsend. Purpose: JP_3-1. Date: 2017/08/16.
 */
public class myFile {
    
    public myFile() {
        
    try { 
    System.out.println("Finding file...");
    InputStream iS = new FileInputStream("myFile.txt");
    System.out.println("File Open.");
}
    catch (Exception e) {
    System.out.println("File not found.");
}
}
}
