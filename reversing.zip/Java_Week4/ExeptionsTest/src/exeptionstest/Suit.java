/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionstest;

/**
 *
 * @author Suzanne Townsend. Purpose: JP_3-6. Date: 2017/08/16.
 */
public abstract class Suit {
    public static final int clubs = 1;
    public static final int spades = 2;
    public static final int diamonds =3;
    public static final int hearts = 4;
    
}
