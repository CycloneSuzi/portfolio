/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionstest;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Suzanne Townsend. Purpose: JP_3-1. Date: 2017/08/16.
 */
public class Invariants {

    public Invariants() {
        
        int internalInvariant = -1;

        if (internalInvariant > 0) {
            System.out.println("The number is more than 0");
        } else {
            assert (internalInvariant == 0);
            System.out.println("Number is not more than zero.");
        }
    }

    public void ControlFlowInvariants() {

        Scanner sc = new Scanner(System.in);
        int suit = sc.nextInt();

        switch (suit) {
            case 1:
                System.out.println("Clubs");
                break;
            case 2:
                System.out.println("Spades");
                break;
            case 3:
                System.out.println("Diamonds");
                break;
            case 4:
                System.out.println("Hearts");
                break;
            default:
                assert false : "unknown playing card";
                break;

        }

    }

    public Object ClassInvariants() {

        ArrayList<Integer> items = new ArrayList<>();
        int size = items.size();
        if (size == 0) {
            throw new RuntimeException("Attempt to pop from empty stack");
        } else {
            Object result = items.remove(-0);
            assert (items.get(items.size()) == items.size() - 1);
            return result;
        }
    }
}
